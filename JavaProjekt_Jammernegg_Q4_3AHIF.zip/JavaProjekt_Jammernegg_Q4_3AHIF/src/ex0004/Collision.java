package ex0004;

public enum Collision
{
  UPPER,LEFT,RIGHT,BOTTOM,NO;
}
